import streamlit as st

def education_page():
    st.markdown("## Education")
    
    st.markdown("""
    ### Master of Science in Marketing
    **The Chinese University of HongKong** | *August 2024 - November 2025*
    
    - Core Courses: Big Data Marketing, Digital Marketing, Consumer Behavior, Marketing Research, Machine Learning, Social Media Analytics
    
    ### Bachelor of Science in Marketing
    **Southwestern University of Finance and Economics** | *September 2020 - June 2024*
    
    - GPA: 3.7/4.0
    - Graduated with Honors
    - Awards: University-Level Second-Class Academic Scholarship (Top 15%), University-Level Third-Class Academic Scholarship *3 (Top 20%)
    - Relevant Coursework: Consumer Behavior, Marketing Research and Data Analysis, Advertising and Media Management, Big Data Marketing, Principles of Management 
    """)
    
    st.markdown("---")
    
    st.markdown("## Projects")
    
    st.markdown("""
    Marketing Planning Competition   
    - Enhanced the popularity of Lao Liehu Hot Pot Village both online and offline to tap into the new generation market
    - planned a marketing campaign featuring “Murder Mystery Game + Hot Pot Feast,” enriching dining experiences through a combination of eating, playing, and unfolding storyline
    - Conducted a 4P + STP strategic analysis, and completed the planning proposal, reaching the finals (Top 10%)    
        """)
