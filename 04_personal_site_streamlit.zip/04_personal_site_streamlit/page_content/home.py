import streamlit as st
from PIL import Image
import os

def home_page():
    left_col, right_col = st.columns(2)
    left_col.markdown(
        """
        <h2>Fiona YANG</h2> 
        <p>Recent Master's Graduate in Marketing<br> 
        Chinese University of Hong Kong<br>
        1 Mei Tin RD Tai Wai NT, HKSAR<br>
        <a href="mailto:shuqiaoy92@gmail.com">shuqiaoy92@gmail.com</a></p>
        """,
        unsafe_allow_html=True
    )

    # add a photo to the right column
    image_path = os.path.join("static", "images", "image.png") 
    if os.path.exists(image_path):
        image = Image.open(image_path)
        right_col.image(image, width=200) 
    else:
        right_col.warning("Profile image not found")

    st.markdown("---")

    st.markdown(
        """
        ### About Me
        I’m a passionate marketer with a strong academic background and hands-on experience in brand strategy, digital marketing, and market analytics. Holding both a Bachelor’s and Master’s degree in Marketing, I’ve specialized in courses like Big Data Marketing, Marketing Research & Analytics, and Advertising & Media Management—equipping me with the skills to bridge data-driven insights with creative campaigns.  
        My diverse internship experiences in brand planning, social media management, and marketing operations have honed my ability to adapt quickly and deliver results. I thrive on innovation, constantly exploring emerging trends and consumer behaviors to craft fresh, impactful campaigns. Whether it’s product operations or experimental branding, I love turning ideas into actionable strategies.  
        Beyond creativity, I pride myself on resilience, collaboration, and a growth mindset. I excel in fast-paced environments, working cross-functionally to solve challenges, and I’m always eager to learn. Proficient in office suites and analytics tools, I combine technical efficiency with strategic thinking to drive projects forward.
        """
    )

    st.markdown(
        """
        ### Skills
        - Programming Languages: Python, R
        - Data Analysis: Pandas
        - Database: SQL
        - Data Visualization: Tableau
        - Statistical Analysis: Hypothesis Testing, Regression Analysis
        - Communication: Presentation Skills, Technical Writing
        """
    )

    st.markdown("---")
    
    # Interactive component has been moved to the experience page 