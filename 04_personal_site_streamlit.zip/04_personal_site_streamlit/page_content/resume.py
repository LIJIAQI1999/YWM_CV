import streamlit as st
import base64
import os

def resume_page():
    pdf_file_path = os.path.join("static", "docs", "resume.pdf")

    if os.path.exists(pdf_file_path):
        with open(pdf_file_path, "rb") as pdf_file:
            PDFbyte = pdf_file.read()

        # Display the download button
        st.download_button(label="Download Resume",
                        data=PDFbyte,
                        file_name="Shuqiao_Yang_Resume.pdf",
                        mime='application/octet-stream')
    else:
        st.warning("Resume PDF file not found")

    st.title("Shuqiao YANG")

    st.header("Contact Information")
    st.markdown("""
    - **Phone:** +86 177-8063-6136
    - **Email:** shuqiaoy92@gmail.com
    """)

    st.header("EDUCATION")
    st.markdown("""
    **The Chinese University of Hong Kong (QS 36)**  
    *Master of Science in Marketing*  
    *08/2024-11/2025*  
    - Core Courses: Big Data Marketing, Digital Marketing, Consumer Behavior, Marketing Research, Machine Learning, Social Media Analytics

    **Southwestern University of Finance and Economics (211)**  
    *Bachelor of Science in Marketing (Financial Services & Marketing)*  
    *09/2020-06/2024*  
    - GPA: 87/100 (Top 20%)
    - Awards: University-Level Second-Class Academic Scholarship (Top 15%), University-Level Third-Class Academic Scholarship *3 (Top 20%)
    """)

    st.header("INTERNSHIP EXPERIENCE")
    st.markdown("""
    **DSIGN Branding, Hong Kong**  
    *Social Media Copywriting & Planning*  
    *02/2025-03/2025*  
    - Market Research & Planning Execution: Conducted market research for event venues and installations, achieving 20% increase in participation
    - "DSIGN * HashKey Brand Guideline Improvement" Project: Researched venues matching brand tone, shortlisted 21 options
    - "OKX Web3 Night" Event: Negotiated with performers and suppliers, created futuristic atmosphere that sparked social media discussions

    **Dongdao Creative Branding Group, Beijing**  
    *Intern, Brand Planning Department*  
    *04/2024-06/2024*  
    - Comprehensive Brand Solution for China South-to-North Water Diversion Group
    - Promotion Strategy for MixC Shenzhen 2024: Defined target audience profiles and content framework
    - Brand Planning for Haiken Nanfan: Conducted market research using Brand House Model

    **Chagee, Chengdu**  
    *Intern, Brand Marketing Center*  
    *10/2023-12/2023*  
    - Produced 4 market reports on tea industry trends
    - Collaborated on "Cat Nest" and "Sixth Anniversary" campaigns
    - Optimized influencer marketing, achieving 40% exposure increase

    **Fosun Group, Shanghai**  
    *Intern, Marketing Department*  
    *07/2023-09/2023*  
    - Created 30 social media posts for St Hubert brand
    - Conducted consumer insights research for plant-based milk products
    - Assisted in media planning for influencer live streams
    """)

    st.header("PROJECTS")
    st.markdown("""
    **Towngas Telecom AI Marketing Agency Project**  
    *Team Member*  
    *12/2024-03/2025*  
    - Identified 3 core AI marketing trends through data analysis
    - Interviewed 5 experts to identify industry challenges
    - Planned 4 AI Agent features including intelligent customer service

    **Marketing Planning Competition**  
    *Member*  
    *05/2022-07/2022*  
    - Created "Murder Mystery Game + Hot Pot Feast" campaign concept
    - Reached finals (Top 10%) with 4P + STP strategic analysis
    """)

    st.header("EXTRACURRICULAR ACTIVITIES")
    st.markdown("""
    **The New Media Center of the School of Business Administration**  
    *Student Union officer*  
    *09/2020-09/2022*  
    - Managed official account content and video production
    - Supported school sports event operations
    """)

    st.header("PERSONAL STRENGTHS / SKILLS / INTERESTS")
    st.markdown("""
    - **Languages:** IELTS 7.5/9; 1 year's overseas study experience
    - **Self-media Operation:** 4 years experience with 20,000+ likes on Xiaohongshu
    - **Skills:** PS, PR, MS Office, SPSS, SQL, Python
    - **Interests:** Piano (level 10); Award-winning photography
    """)

    st.markdown("---")