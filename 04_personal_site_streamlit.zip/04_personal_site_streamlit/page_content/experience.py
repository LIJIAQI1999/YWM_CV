import streamlit as st
from components.interactive import display_interactive_chart

def experience_page():
    st.markdown("## Experience")
    
    st.markdown("""
    ### Social Media Copywriting & Planning
    **DSIGN Branding** | *Jane 2025*
 
    - Market Research & Planning Execution: Conducted market research to gather various innovative event venue layouts and interactive installation designs, planned creative event flows and interactive segments, ensuring novel and unique event mechanisms that aligned closely with the brand image, and achieved a 20% increase in event participation through the execution of multiple offline events.
    - "DSIGN * HashKey Brand Guideline Improvement" Project: Conducted market research to collect info on event venues that matched the brand's tone, shortlisted 21 alternative venues, and compared their quotes to ensure the best cost-effectiveness, also analyzed the characteristics of the target consumer group and developed targeted communication strategies in conjunction with Web3 market trends
    - "OKX Web3 Night" Event Planning & Execution: Negotiated quotes with performance teams and merchandise suppliers to ensure the performance quality aligned with the brand image, and selected merchandise with brand characteristics, also participated in planning the event venue layout, employing high-tech elements to create a futuristic atmosphere that attracted tech enthusiasts and brand users, with the event sparking discussions on social media platforms such as Facebook, X, and LinkedIn.
    """)
    
    st.markdown("""
    ### Brand Planning Department Intern
    **Dongdao Creative Branding Group** | *January 2024*
    
    - Comprehensive Brand Architecture & Management Technical Services Solution for China South-to-North Water Diversion Group
    - Comprehensive Promotion Strategy Planning and Visual Identity System Design for MixC Shenzhen 2024
    - Brand Planning for Haiken Nanfan
    """)
    
    st.markdown("""
    ### Marketing Department Intern
    **Fosun Group** | *July 2023 - September 2023*
    
    - Social Media Operations: Conceived, filmed, and published promotional materials for company products, and assisted in managing the social media accounts of the St Hubert brand, including content creation and interaction, completed 30 posts.
    - Consumer Insights: Conducted insights into the consumer group for plant-based milk products through field market research, questionnaires, industry reports, and social media data analysis, explored the development models of emerging brands and completed a consumer insights report for the beverage industry.
    - Media Planning: Participated in the brand's media communication planning, providing creative ideas for live streaming by shopping influencers, adding interest tags and trending tags to enhance user activity and engagement.
    """)
    
    st.markdown("""
    ### Brand Marketing Department Intern
    **CHAGEE** | *October 2023 - December 2023*
    
    - Brand Market Project Support: Provided comprehensive support to the team for researching consumer and market trends in the tea and related industries at various stages, focusing on user insights, trending topics, and pre-marketing strategies, and culminating in 4 market reports.
    - Event Planning & Execution: Collaborated in planning and executing online and offline events aligned with marketing and promotion strategies, contributed to projects like "Cat Nest" and "Sixth Anniversary" by developing engaging content and promotion plans, and crafted detailed execution plans.
    - Advertising Strategy Optimization: Precisely segmented influencer types and content directions, performed audience profiling to ensure targeted influencer selection, cooperation, and execution follow-up, also employed "Dou+" advertising to boost traffic, conversions, and demand, achieving a 40% exposure rate increase and a seven-position jump in competitive rankings.
    - Data Collection & Analysis: Gathered data on voice volume and interactions, used Excel to analyze market, demographic, content, and touchpoint impacts, and suggested avoiding content that might negatively impact the brand to enhance NPS scores.
    """)

    st.markdown("---")
    
    st.markdown("## Projects")
    
    projects = [
        {
            "title": "Towngas Telecom AI Marketing Agency Project",
            "description": "Employed web crawling and primary/secondary data analysis to uncover 3 core development trends of AI marketing in the ICT industry.",
            "skills": ["Python", "Pandas", "Matplotlib"],
            "outcome": "The planning of 4 core features for the AI Agent, including an intelligent customer service system, intelligent advertising optimization, integrated social media management, and efficient project management, aiming to enhance overall marketing operational efficiency and customer interaction experiences for enterprises through these functionalities."
        }
    ]  # Fixed: Removed the trailing comma that was making this a tuple

    for i, project in enumerate(projects):
        with st.expander(f"{project['title']}", expanded=i==0):
            st.markdown(f"**Description:** {project['description']}")
            st.markdown(f"**Skills Used:** {', '.join(project['skills'])}")
            st.markdown(f"**Outcome:** {project['outcome']}")
    
    # Add the interactive visualization demo
    with st.expander("Interactive Data Visualization Demo", expanded=False):
        st.markdown("**Description:** An interactive demonstration of various data visualization techniques.")
        display_interactive_chart()
    
    st.markdown("---")
    
    st.markdown("## Professional Skills")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### Technical Skills
        - **Programming Languages:** Python, R, SQL, JavaScript
        - **Data Processing:** Pandas
        - **Visualization:** Matplotlib, Tableau
        """)
        
    with col2:
        st.markdown("""
        ### Soft Skills
        - Languages: IELTS 7.5/9; 1 year's overseas study experience; adapted to the English-speaking environment
        - Self-media Operation: 4 years of experience in comprehensive platform operation, accumulating 20,000 likes and collections for personal account on Xiaohongshu, with over 5 viral posts receiving 1,000+ likes each
        - Interests: Piano (level 10); Photography (participated in many photography competitions and won awards)
        """)
    
    st.markdown("---")

# If this is meant to be run as a standalone script
if __name__ == "__main__":
    experience_page()