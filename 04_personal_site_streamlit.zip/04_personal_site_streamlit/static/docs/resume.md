# YANG Shuqiao

## Contact Information
- **Email:** shuqiaoy92@gmail.com  
- **Phone:** (86) 177-8063-6136  

## Professional Summary
Results-driven marketing professional with a Master’s degree in Marketing and hands-on experience in brand strategy, social media management, and data-driven marketing. Adept at market research, consumer insights, and cross-functional collaboration. Seeking a dynamic role to leverage analytical and creative skills in a forward-thinking organization.

## Work Experience
**Social Media Copywriting & Planning Intern**, DSIGN Branding, Hong Kong  
*02/2025–03/2025*  
- Conducted market research to innovate event layouts, boosting participation by 20%.  
- Led the *DSIGN × HashKey Brand Guideline Improvement* project, shortlisting 21 venues and optimizing cost-effectiveness.  
- Executed *OKX Web3 Night*, integrating high-tech elements to drive social media engagement.  

**Brand Planning Intern**, Dongdao Creative Branding Group, Beijing  
*04/2024–06/2024*  
- Diagnosed brand architecture for China South-to-North Water Diversion Group, delivering a strategic report.  
- Developed consumer profiles and content frameworks for MixC Shenzhen’s 2024 campaign.  
- Analyzed competitive advantages for Haiken Nanfan using the Brand House Model.  

**Brand Marketing Intern**, Chagee, Chengdu  
*10/2023–12/2023*  *(Fixed missing "3" in year)*  
- Produced 4 market reports on tea industry trends and executed online/offline campaigns.  
- Optimized influencer advertising, increasing exposure by 40% and improving competitive rankings.  

## Education
**Master of Science in Marketing**  
The Chinese University of Hong Kong  
*Expected Graduation: October 2025*  *(Clarified "expected" for future date)*  
- GPA: 3.7/4.0  

**Bachelor of Science in Marketing (Financial Services & Marketing)**  
Southwestern University of Finance and Economics  
*Graduated: June 2024*  
- GPA: 3.7/4.0  

## Skills
- **Technical:** SPSS, SQL, Python, PS, PR, MS Office  
- **Marketing:** Brand Strategy, Social Media, Data Analysis, Consumer Insights *(Fixed "Insight" → "Insights")*  
- **Languages:** English (IELTS 7.5), Mandarin (Native)  

## Projects
**Towngas Telecom AI Marketing Agency Project**  
- Identified *(Fixed typo "dentified")* 3 AI marketing trends and designed 4 core features (e.g., intelligent customer service) to address industry challenges.  

## Interests *(Fixed inconsistent heading format "##Interests" → "## Interests")*
- Piano (Level 10)  
- Photography (Award-winning in competitions)  
- Hiking and outdoor activities  